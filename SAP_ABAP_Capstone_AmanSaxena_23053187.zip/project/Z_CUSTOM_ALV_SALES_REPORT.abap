*&---------------------------------------------------------------------*
*& Report  Z_CUSTOM_ALV_SALES_REPORT
*& Author  : Aman Saxena
*& Roll No : 23053187
*& Batch   : 2027 (CSE)
*& Project : SAP ABAP Custom ALV Sales Order Report
*&---------------------------------------------------------------------*

REPORT z_custom_alv_sales_report.

TABLES: vbak, vbap, kna1.
TYPE-POOLS: slis.

"===========================================================
" Data Types
"===========================================================
TYPES: BEGIN OF ty_report,
  vbeln  TYPE vbak-vbeln,
  erdat  TYPE vbak-erdat,
  kunnr  TYPE vbak-kunnr,
  name1  TYPE kna1-name1,
  matnr  TYPE vbap-matnr,
  kwmeng TYPE vbap-kwmeng,
  netwr  TYPE vbak-netwr,
END OF ty_report.

"===========================================================
" Global Variables
"===========================================================
DATA: gt_report   TYPE TABLE OF ty_report,
      gs_report   TYPE ty_report,
      gt_fieldcat TYPE slis_t_fieldcat_alv,
      gs_fieldcat TYPE slis_fieldcat_alv,
      gs_layout   TYPE slis_layout_alv,
      gt_sort     TYPE slis_t_sortinfo_alv,
      gs_sort     TYPE slis_sortinfo_alv.

"===========================================================
" Selection Screen
"===========================================================
SELECTION-SCREEN BEGIN OF BLOCK b1 WITH FRAME TITLE TEXT-001.
  SELECT-OPTIONS: s_date  FOR vbak-erdat OBLIGATORY,
                  s_vkorg FOR vbak-vkorg,
                  s_kunnr FOR vbak-kunnr.
SELECTION-SCREEN END OF BLOCK b1.

"===========================================================
" Start of Selection
"===========================================================
START-OF-SELECTION.

  PERFORM fetch_data.
  PERFORM build_fieldcat.
  PERFORM build_layout.
  PERFORM build_sort.
  PERFORM display_alv.

"===========================================================
" Form: Fetch Data
"===========================================================
FORM fetch_data.
  SELECT a~vbeln
         a~erdat
         a~kunnr
         b~name1
         c~matnr
         c~kwmeng
         a~netwr
    INTO TABLE gt_report
    FROM vbak AS a
    INNER JOIN kna1 AS b ON a~kunnr = b~kunnr
    INNER JOIN vbap AS c ON a~vbeln = c~vbeln
   WHERE a~erdat IN s_date
     AND a~vkorg IN s_vkorg
     AND a~kunnr IN s_kunnr.

  IF sy-subrc <> 0.
    MESSAGE 'No records found for the given selection.' TYPE 'I'.
    LEAVE LIST-PROCESSING.
  ENDIF.
ENDFORM.

"===========================================================
" Form: Build Field Catalog
"===========================================================
FORM build_fieldcat.
  CLEAR gs_fieldcat.
  gs_fieldcat-fieldname   = 'VBELN'.
  gs_fieldcat-seltext_m   = 'Sales Order'.
  gs_fieldcat-outputlen   = 10.
  gs_fieldcat-hotspot     = 'X'.
  APPEND gs_fieldcat TO gt_fieldcat.

  CLEAR gs_fieldcat.
  gs_fieldcat-fieldname   = 'ERDAT'.
  gs_fieldcat-seltext_m   = 'Order Date'.
  gs_fieldcat-outputlen   = 10.
  APPEND gs_fieldcat TO gt_fieldcat.

  CLEAR gs_fieldcat.
  gs_fieldcat-fieldname   = 'KUNNR'.
  gs_fieldcat-seltext_m   = 'Customer No.'.
  gs_fieldcat-outputlen   = 10.
  APPEND gs_fieldcat TO gt_fieldcat.

  CLEAR gs_fieldcat.
  gs_fieldcat-fieldname   = 'NAME1'.
  gs_fieldcat-seltext_m   = 'Customer Name'.
  gs_fieldcat-outputlen   = 30.
  APPEND gs_fieldcat TO gt_fieldcat.

  CLEAR gs_fieldcat.
  gs_fieldcat-fieldname   = 'MATNR'.
  gs_fieldcat-seltext_m   = 'Material No.'.
  gs_fieldcat-outputlen   = 18.
  APPEND gs_fieldcat TO gt_fieldcat.

  CLEAR gs_fieldcat.
  gs_fieldcat-fieldname   = 'KWMENG'.
  gs_fieldcat-seltext_m   = 'Quantity'.
  gs_fieldcat-outputlen   = 10.
  gs_fieldcat-do_sum      = 'X'.
  APPEND gs_fieldcat TO gt_fieldcat.

  CLEAR gs_fieldcat.
  gs_fieldcat-fieldname   = 'NETWR'.
  gs_fieldcat-seltext_m   = 'Net Value'.
  gs_fieldcat-outputlen   = 15.
  gs_fieldcat-do_sum      = 'X'.
  APPEND gs_fieldcat TO gt_fieldcat.
ENDFORM.

"===========================================================
" Form: Build Layout
"===========================================================
FORM build_layout.
  gs_layout-zebra          = 'X'.
  gs_layout-colwidth_optimize = 'X'.
  gs_layout-totals_text    = 'Grand Total'.
ENDFORM.

"===========================================================
" Form: Build Sort
"===========================================================
FORM build_sort.
  CLEAR gs_sort.
  gs_sort-fieldname = 'KUNNR'.
  gs_sort-up        = 'X'.
  gs_sort-subtot    = 'X'.
  APPEND gs_sort TO gt_sort.
ENDFORM.

"===========================================================
" Form: Display ALV
"===========================================================
FORM display_alv.
  CALL FUNCTION 'REUSE_ALV_GRID_DISPLAY'
    EXPORTING
      i_callback_program = sy-repid
      it_fieldcat        = gt_fieldcat
      is_layout          = gs_layout
      it_sort            = gt_sort
    TABLES
      t_outtab           = gt_report
    EXCEPTIONS
      program_error      = 1
      OTHERS             = 2.

  IF sy-subrc <> 0.
    MESSAGE 'Error displaying ALV report.' TYPE 'E'.
  ENDIF.
ENDFORM.
