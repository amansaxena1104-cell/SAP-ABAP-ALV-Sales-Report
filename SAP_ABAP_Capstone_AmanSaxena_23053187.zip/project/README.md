# SAP ABAP Custom ALV Sales Order Report

> **Capstone Project** | Aman Saxena | Roll No: 23053187 | Batch: 2027 (CSE) | Specialization: SAP ABAP Development

---

## Overview

This project implements a custom SAP ABAP ALV (ABAP List Viewer) Report to display Sales Order data with advanced filtering, sorting, subtotals, and Excel export functionality.

Standard SAP transactions may not provide the exact custom fields and layout required by business users. This report bridges that gap by offering a flexible, user-friendly interface for sales order monitoring.

---

## Features

| Feature | Description |
|---|---|
| Selection Screen | Date range, Sales Org, Customer filters |
| Multi-table JOIN | Fetches from VBAK, VBAP, KNA1 |
| ALV Grid Display | Columnar output with hotspot on Sales Order |
| Subtotals | Grouped by Customer with quantity & value totals |
| Grand Total | Sum of Quantity and Net Value |
| Export to Excel | Built-in ALV toolbar option |
| Zebra Striping | Enhanced readability |

---

## Tech Stack

- **SAP GUI** – User Interface
- **ABAP** – Programming Language (Release 7.50+)
- **Transaction SE38** – ABAP Editor
- **Function Module** – `REUSE_ALV_GRID_DISPLAY`
- **SAP Tables** – VBAK (Sales Order Header), VBAP (Sales Order Item), KNA1 (Customer Master)

---

## Project Structure

```
project/
│
├── Z_CUSTOM_ALV_SALES_REPORT.abap   ← Main ABAP source code
├── README.md                         ← This file
├── Project_Report.pdf                ← Full project documentation (PDF)
└── Screenshots/
    ├── fig1_se38_editor.png
    ├── fig2_code_activated.png
    ├── fig3_selection_screen.png
    ├── fig4_alv_output.png
    └── fig5_excel_export.png
```

---

## How to Run

1. Open **SAP GUI** and log in to your SAP system.
2. Go to transaction **SE38**.
3. Enter program name: `Z_CUSTOM_ALV_SALES_REPORT`.
4. Click **Create**, paste the source code, and **Activate** (Ctrl+F3).
5. Execute the program (F8).
6. Enter a **date range** on the selection screen and press Execute.
7. The ALV Grid report will display with all sales order data.
8. Use the **Export** button in the toolbar to download as Excel.

---

## SAP Tables Used

| Table | Description |
|---|---|
| VBAK | Sales Order Header Data |
| VBAP | Sales Order Item Data |
| KNA1 | Customer Master General Data |

---

## Future Enhancements

- Automatic email delivery of the report
- Graphical charts / dashboard integration
- SAP Fiori conversion for web-based access
- Authorization object checks (role-based access)
- Dynamic column selection by end user

---

## Viva Preparation

1. **What is ALV in SAP ABAP?**  
   ALV (ABAP List Viewer) is a standard SAP tool for displaying tabular data in a structured, interactive grid format with sort, filter, and export capabilities.

2. **What is REUSE_ALV_GRID_DISPLAY?**  
   It is a standard SAP function module that renders data in an ALV Grid. You pass a field catalog (column definitions) and an internal table (data) to it.

3. **Why INNER JOIN?**  
   To combine related data from multiple tables (VBAK, KNA1, VBAP) into a single result set, ensuring only records with matching keys across all three tables are returned.

4. **What are VBAK, VBAP, KNA1?**  
   VBAK = Sales Order Header, VBAP = Sales Order Line Items, KNA1 = Customer Master.

5. **What is a selection screen?**  
   It is the input screen that allows users to filter data before execution using parameters and select-options.

---

## Author

**Aman Saxena**  
Roll No: 23053187  
Batch: 2027 (CSE)  
Specialization: SAP ABAP Development
