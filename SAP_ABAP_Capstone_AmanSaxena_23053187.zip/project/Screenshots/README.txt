Screenshots to capture and add here:

Fig 1: SE38 Editor Screen showing program name Z_CUSTOM_ALV_SALES_REPORT
Fig 2: ABAP code in editor after successful activation (status bar shows "Object activated")
Fig 3: Selection screen with date range filled in
Fig 4: ALV Grid output showing sales order records with subtotals
Fig 5: ALV toolbar with Excel export option highlighted

How to take screenshots in SAP GUI:
- Use Alt+PrintScreen or SAP GUI's built-in screenshot tool
- Save as PNG files named fig1_se38_editor.png, fig2_code_activated.png, etc.
